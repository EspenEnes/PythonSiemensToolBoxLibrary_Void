import sys
import platform

MAJOR = 0
MINOR = 0
MICRO = 0
VERSION = f"{MAJOR}.{MINOR}.{MICRO}"

min_version = (3, 7, 0)

def is_right_py_version(min_py_version):
    if sys.version_info < (3,):
        sys.stderr.write("Python 2 is not supported")
        return False

    if sys.version_info < min_py_version:
        python_min_version_str = ".".join((str(num) for num in min_py_version))
        no_go = f"You are using Python {platform.python_version()}. Python >={python_min_version_str} is  required."
        sys.stderr.write(no_go)
        return False

    return True

if not is_right_py_version(min_version):
    sys.exit(-1)


from setuptools import setup, find_packages
setup(
    NAME = "PythonSiemensToolboxLibrary",
    AUTHOR = "Espen Enes",
    AUTHOR_EMAIL = "espenenes@hotmail.com",
    AUTHOR_LONG = "Espen Enes" + " <" + "espenenes@hotmail.com" + ">",
    LICENSE = "MIT License",
    # FUNDING = ,
    PLATFORMS = ["Any"],
    GIT_URL = "https://github.com/EspenEnes/PythonSiemensToolBoxLibrary",
    # DOCS_URL = ,
    # DOWNLOAD_URL =
    PACKAGES = [i for i in find_packages() if "tests" not in i],
    DESCRIPTION = "Python package to read Step7 project files and blocks",
    LONG_DESCRIPTION = "Python package to read Simatic Step7 projects, to extract content from DBs",
    KEYWORDS = ["toolbox", "siemens", "step7", "plc"],
    REQUIREMENTS = ["dbfread"],
    CLASSIFIERS = [ "Development Status :: 3 - Alpha",
                    "Programming Language :: Python :: 3",
                    "Intended Audience :: Education",
                    ],
    PYTHON_REQUIRES = ">=3.7")



def setup_package():
    # Rewrite the meta file everytime
    write_meta()

    metadata = dict(
        name = NAME,
        version = VERSION,
        author = AUTHOR,
        author_email = AUTHOR_EMAIL,
        maintainer = AUTHOR,
        description = DESCRIPTION,
        long_description = LONG_DESCRIPTION,
        long_description_content_type = "text/markdown",
        url = GIT_URL,
        download_url = DOWNLOAD_URL,
        project_urls = {
            "Bug Tracker": GIT_URL + "/issues",
            "Documentation": get_docs_url(),
            "Funding": FUNDING,
            "Source Code": GIT_URL,
        },
        packages = PACKAGES,
        # ext_modules = EXT_MODULES,
        license = LICENSE,
        platforms = PLATFORMS,
        install_requires = REQUIREMENTS,
        python_requires = PYTHON_REQUIRES,
        # cmdclass = CMDCLASS,
# Include_package_data is required for setup.py to recognize the MAINFEST.in file
# https://python-packaging.readthedocs.io/en/latest/non-code-files.html
        include_package_data = True,
        zip_safe = False,
        keywords = KEYWORDS,
        classifiers = CLASSIFIERS,
    )

if __name__ == "__main__":
    # Running the build is as simple as:
    # >> python setup.py sdist bdist_wheel
    # This command includes building the required Python extensions (Cython included)

    # It"s recommended, however, to use:
    # >> python setup.py build_ext
    # first, and then
    # >> python setup.py sdist bdist_wheel
    setup_package()